#JAVA_HOME=
${JAVA_HOME}/bin/java -cp '.:./lib/*:kie-server-fx.jar' org.fxapps.kieserverclient.cdi.CDIApplication
